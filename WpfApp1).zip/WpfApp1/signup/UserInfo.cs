﻿using System.ComponentModel.DataAnnotations;

namespace WpfApp1.signup
{
    public class UserInfo
    {
        [Required(ErrorMessage = "Укажите имя")]
        [RegularExpression(@"[a-zA-Z0-9_]+",
        ErrorMessage = "Имя пользователя может содержать только латинские буквы, цифры и символ подчеркивания.")]
        public string Username { get; set; } = string.Empty;

        [StrongPassword]
        public string Password { get; set; } = string.Empty;

        [Compare(nameof(Password), ErrorMessage = "Пароли не совпадают.")]
        public string RepeatPassword { get; set; } = string.Empty;
    }
}