﻿using System.ComponentModel.DataAnnotations;

namespace WpfApp1.signup
{
    public class StrongPasswordAttribute : ValidationAttribute
    {
        public override bool IsValid(object? value)
        {
            string password = value?.ToString() ?? string.Empty;
            if (string.IsNullOrEmpty(password) || password.Length < 8)
            {
                ErrorMessage = "Пожалуйста, укажите надежный пароль.";
                return false;
            }

            bool hasLower = false;
            bool hasUpper = false;
            bool hasDigit = false;
            bool hasSpecial = false;

            foreach (char ch in password)
            {
                if (char.IsLower(ch))
                    hasLower = true;
                else if (char.IsUpper(ch))
                    hasUpper = true;
                else if (char.IsDigit(ch))
                    hasDigit = true;
                else if (!char.IsLetterOrDigit(ch))
                    hasSpecial = true;
            }

            if (!hasLower)
            {
                ErrorMessage = "Пароль должен содержать хотя бы одну букву в нижнем регистре.";
                return false;
            }

            if (!hasUpper)
            {
                ErrorMessage = "Пароль должен содержать хотя бы одну букву в верхнем регистре.";
                return false;
            }

            if (!hasDigit)
            {
                ErrorMessage = "Пароль должен содержать хотя бы одну цифру.";
                return false;
            }

            if (!hasSpecial)
            {
                ErrorMessage = "Пароль должен содержать хотя бы один спецсимвол.";
                return false;
            }

            return true;
        }
    }
}